import java.lang.reflect.Array;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
public class Main {

    public void run() {

        int counter = 0;
        boolean pos = true;
        boolean tanpos = true;
        boolean change = false;
        double tangent =0;
        double prevtangent;

        ArrayList<Double> outputs = new ArrayList(); //Original outputs of function x squared

        ArrayList<Double> mini = new ArrayList();  // Arraylist meant to be rewritten over with the ten values per decimal point going down

        Point proto = new Point();
        // For now, just contains ints that I use to create the x and ys of x squared and some doubles to deal with the values in between the two smallest integers in the function
        //bigger range

        for (double x = -5; x < 10; x= x+.5) { //This for loop prints out 21 values from the function x sqaured and takes from it the minimum value
            proto.a = x;
            proto.calcFunction();
            outputs.add(proto.y);
            counter++;

            proto.printFunction();
            System.out.println(outputs.size());
            /*proto.b = proto.y;
            proto.hold = proto.b;
            if (proto.b < proto.min) {
                proto.min = proto.b;
            }
            if (x == -10) {
                proto.min = proto.b;
            }*/
        }
        for(int a = 2; a<=29;a++){
            prevtangent = tangent;
            tanpos = !(prevtangent < 0);
            tangent = outputs.get(a) - outputs.get(a-1);
            pos = !(tangent < 0);
            if (pos != tanpos){
                System.out.println("INFLEXION POINT"+ a + "////////////////////////////////////////////////////////////////////////");
            }
        }
        for (int point = 0; point < outputs.size()-1; point++) { //This for loop gets the two smallest integers
            if (outputs.get(point) == proto.min) {
                proto.hold = outputs.get(point - 1);
                proto.hold2 = outputs.get(point);

            }
        }
        //System.out.println("RAN MINI SCANNER: " + counter);
        for(double x = proto.hold; x>proto.hold2;x=x-.10) { //This for loop adds the values in between the two smallest integers
            mini.add(x);
            System.out.println("Min: "+x);
        }

        for(double y = proto.hold; y<proto.hold2;y=y+.1){  //maximum?
            mini.add(y);
            System.out.println("Max: "+y);
        }

        //Get the Tangent and make it work with minimum
        /*System.out.println("The size of ytable is: " + outputs.size());
        System.out.println("The minimum is: " + proto.min);
        System.out.println("The first hold value is: " + proto.hold);
        System.out.println("The second hold value is: " + proto.hold2);
        System.out.println("TEST ");
        for(int dec = 0; dec < mini.size(); dec++){
            System.out.println("Minimum: " + mini.get(dec));

        }*/
    }
}

