import java.util.Scanner;
import java.util.ArrayList;
import java.util.*;
public class Point {
    double a;
    double b;
    double hold;
    double hold2;
    double min;
    double y;
    double mag;

    public void calcFunction(){
        y = Math.sin(a);
    }

    public void printFunction(){
        System.out.println(a + "," + y);
    }
}
