import java.util.ArrayList;
import java.util.Scanner;

public class Arith_Geo {
    public double num;
    public int n;
    public double difference;
    public double ratio;
    public boolean seqExists = false;
    public boolean arithmetic = true;
    public boolean geometric = true;
    public boolean noSequence;
    public void run(){
        Scanner series = new Scanner(System.in);
        ArrayList<Double> sequence = new ArrayList<>();
        for (double x = 0; x < 4; x++) {
            System.out.println("Input next term");
            num = series.nextDouble();
            sequence.add(num);
        }
        difference =  sequence.get(1) - sequence.get(0);
        ratio = sequence.get(1)/sequence.get(0);
        for(int s=0; s < sequence.size();s++){
            System.out.print(sequence.get(s)+ ", ");
        }
        for(int x = 1; x<sequence.size(); x++){
            if(sequence.get(x)-sequence.get(x-1) != difference){
                arithmetic = false;
            }
        }
        for(int a = 1; a<3;a++){
            if(sequence.get(a)/sequence.get(a-1) != ratio){
                geometric = false;
            }
        }
        if (arithmetic == true) {
            System.out.println("");
            System.out.println("This sequence is arithmeitc. The common difference is: " + difference);
        }
        if (geometric == true) {
            System.out.println("");
            System.out.println("This sequence is geometric. The common ratio is: " + ratio);
        }
        //Finding the nth term
        if( geometric == false && arithmetic == false){
            noSequence = true;
        }
        if(noSequence == false) {
            Scanner nthTerm = new Scanner(System.in);
            System.out.println("Input nth term");
            n = nthTerm.nextInt();
            if (arithmetic == true) {
                System.out.println("Your nth term is: " + (sequence.get(0) + ((n - 1) * difference)));
            }
            if (geometric == true) {
                System.out.println("Your nth term is:" + (sequence.get(0) * Math.pow(ratio, n - 1)));
            }
        } else {
            System.out.println("The terms you inserted do not form an Arithmetic or Geometric sequence");
        }
    }
}
