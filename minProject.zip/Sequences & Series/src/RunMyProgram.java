public class RunMyProgram {
    public static void main(String[] args) {
//        Seq & series project done a while ago
//        Arith_Geo seq = new Arith_Geo();
//        seq.run();

        Main ex = new Main();   //creates a new instance of the game
        ex.run();                 //calls the run method from the Main method
    }
}