public class NarrowDown {
    public NarrowDown(int previousSize ){

    }
}
