import java.util.Scanner;
import java.util.ArrayList;
public class Main {


    public static void main(String[] args) {
//MinimumValue.main();

    }
}

