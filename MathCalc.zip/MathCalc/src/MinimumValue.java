import java.util.ArrayList;

public class MinimumValue {
    public static ArrayList<Double> inputs;
    public static ArrayList<Double> matching;
    public static double leastX = -1000;
    public static double mostX = 1000;
    //public static double leastSoFar = 1000;
    public static double xValueCorr;
    //public static boolean goneThroughAll;
    public static double exponent = 0;
    public static double corrJ;
    public static double leastSub=1000;
    //public static int higherLeastI;
    //setting (x-h)^2 + k
    public static double constantXChange= 247.8937;//(h)
    public static double constantYChange = 72.9857;//(k)
    public static double constantPower=2;
    public static double tempX;
    public static double tempY;
    public static double measurer=1000;

    //easier Math.pow function  vvv
    public static double equation(double base, double power, double xChange, double yChange){
        double returner=0.0112358;
        returner = Math.pow(base - xChange, power)+yChange;
        //System.out.println(returner);
        return returner;
    }
    //i*7+9

    public static void main() {

//        ArrayList<Double> matching = new ArrayList<>();
        if ( equation(1,constantPower,constantXChange,constantYChange)- equation(0,constantPower,constantXChange,constantYChange) == equation(2,2,constantXChange,constantYChange) - equation(1,2,constantXChange,constantYChange)){
            System.out.println("This is linear, therefore the smallest value is -infinity");
            //checks if linear equation
        }
        else{

            while((mostX-leastX)/ equation(10,exponent,0,0)>1){
                //finds what magnitude of 10^x this number can be divided to a whole number
                exponent++;
                System.out.println(exponent);
            }
        }
        for (double i = 0; i < exponent+7; i++) {
            System.out.println("YOU MADE IT");

            if(i==0){
                for (double j = leastX; j < mostX; j+=Math.pow(10,exponent-2-i)) {//for Math.pow(10,exponent-1), the 1 is indicating how many iterations I have [if exponent is 5, i will go through and make ten groups of 10^4
                    System.out.println(j);
                    if (Math.abs(equation((j+Math.pow(10,exponent-1-i)), constantPower, constantXChange, constantYChange) - equation(j, constantPower, constantXChange, constantYChange)) < Math.abs(leastSub)) {
                        leastSub = Math.abs((equation((j+Math.pow(10,exponent-1-i)), constantPower, constantXChange, constantYChange) - equation(j, constantPower, constantXChange, constantYChange)));
                        corrJ = j;
                        //System.out.println(inputs.get(0));
                        //System.out.println(matching.get(0));

                    }

                }
                //tempY = Math.abs(equation(corrJ, constantPower, constantXChange, constantYChange) - equation(corrJ - 1, constantPower, constantXChange, constantYChange));
                tempX=corrJ;
                System.out.println(corrJ);
                System.out.println("First time");
            }
            else if((i>0)&&(i<exponent+6)) {
                for (double j = tempX; j < (tempX+Math.pow(10,exponent-i-2)); j+= Math.pow(10,exponent-i-3)){
                    //((mostX - leastX)) / Math.pow(10, exponent - i); j += Math.pow(10, exponent - i)) {//for Math.pow(10,exponent-1), the 1 is indicating how many iterations I have [if exponent is 5, i will go through and make ten groups of 10^4
                    //
                    if (Math.abs(equation(j+Math.pow(10,exponent-i-2), constantPower, constantXChange, constantYChange) - equation(j, constantPower, constantXChange, constantYChange)) < Math.abs(leastSub)) {
                        leastSub = Math.abs((equation(j+Math.pow(10,exponent-i-2), constantPower, constantXChange, constantYChange) - equation(j, constantPower, constantXChange, constantYChange)));

                        //System.out.println(inputs.get(0));
                        //System.out.println(matching.get(0));
                        //tempY = Math.abs(equation(j, constantPower, constantXChange, constantYChange));
                        tempX = j;
                    }


                }
                System.out.println(tempX);
                System.out.println("Not first");
            }
            else {
                for (double j = tempX; j < (tempX+Math.pow(10,exponent-i-2)); j+= Math.pow(10,exponent-i-3)) {
                    if ((equation(j, constantPower, constantXChange, constantYChange) < measurer)) {
                        measurer = (equation(j, constantPower, constantXChange, constantYChange));
                        tempX = j;
                        tempY = equation(j,constantPower,constantXChange,constantYChange);
                    }
                }
            }

            //System.out.println(j);
//                System.out.println(inputs.get(0));
//                System.out.println(matching.get(0));




        }



        //System.out.println(higherLeastI + " " + leastSub);
//        leastSoFar = (Math.pow((higherLeastI-Math.pow(10,exponent)),2)+60);
//        for (double i = (higherLeastI-Math.pow(10,(exponent-2))); i <mostX; i+=0.1) {//iterates, by every 0.1 through the designated 1 of the ten bars I identified to contain the minimum
//            if (leastSoFar >equation(i,constantPower,constantXChange,constantYChange)) {
//                leastSoFar = equation(i,constantPower,constantXChange,constantYChange);
//                xValueCorr = i;
//                //System.out.println(leastSoFar + " " + xValueCorr);
//            }
//        }
//            xValueCorr *= 1000;  // all this is to round the final answer to get rid of the 1.0000000000018 nonsense ( this is for glamour and not needed)
//            xValueCorr = (int)xValueCorr;
//            xValueCorr /= 1000;
//        leastSoFar *= 1000;
//        leastSoFar = (int)leastSoFar;
//        leastSoFar /= 1000;

        System.out.println("The smallest point is: (" + tempX + ", " + tempY + ")");


    }

}

