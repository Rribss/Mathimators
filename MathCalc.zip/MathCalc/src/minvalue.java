public class minvalue {
    public static double yCutoffs = 10^100;
    public int a = 1;
    public int b = 5;
    public int c = 2;

    public static double xValue(int a, int b, int c, int y) {
        if (y>0) {
            int x = (int) ((-b + Math.sqrt(b * 2 - 4 * a * c)) / (2 * a));
        }
        


        return x;
    }
}
